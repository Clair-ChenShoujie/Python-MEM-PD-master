import numpy as np
import pandas as pd

df2 = pd.read_excel("2023华数B/附件2.xlsx", sheet_name="标准ks", header=None)
ks1 = df2.iloc[0:3, 0:16].values.astype('float64')  # k/s
ks0 = [0.039492, 0.025906, 0.017964, 0.015092, 0.011439, 0.009515, 0.007961, 0.006947, 0.006284, 0.005889, 0.005238, 0.004948, 0.004626, 0.004247, 0.004100, 0.003617]
red_des = np.array([0.05, 0.1, 0.5, 1, 2, 3, 4, 5])  # 红浓度
yel_des = np.array([0.05, 0.1, 0.5, 1, 2, 3, 4, 5])  # 黄浓度
blu_des = np.array([0.05, 0.1, 0.5, 1, 2, 3, 4, 5])  # 蓝浓度

results = []

# 红黄
for j in range(len(red_des)):
    for i in range(len(yel_des)):
        ks = ks0 + red_des[j] * ks1[0, :] + yel_des[i] * ks1[1, :]
        results.append(ks)

# 红蓝
for j in range(len(red_des)):
    for k in range(len(blu_des)):
        ks = ks0 + red_des[j] * ks1[0, :] + blu_des[k] * ks1[2, :]
        results.append(ks)

# 黄蓝
for i in range(len(yel_des)):
    for k in range(len(blu_des)):
        ks = ks0 + yel_des[i] * ks1[1, :] + blu_des[k] * ks1[2, :]
        results.append(ks)

# 创建DataFrame对象
df = pd.DataFrame(results)

# 将数据写入Excel文件
df.to_excel('2023华数B/二色.xlsx', index=False)
