# 读取数据
import numpy as np
import pandas as pd

df2 = pd.read_excel("2023华数B/附件2.xlsx",sheet_name="标准ks", header=None)
ks_single = df2.iloc[0:3, 0:16].values.astype('float64')  # k/s

values = np.array([0.05, 0.1, 0.5, 1, 2, 3, 4, 5])

result = np.empty((3, 8, ks_single.shape[1]), dtype=float)  # 创建一个空的三维数组,一维颜色，二维浓度，三维波长

# 对每个颜色数组进行操作
for i in range(ks_single.shape[0]):
    for j, v in enumerate(values):
        result[i, j, :] = np.multiply(ks_single[i, :], v)

# 将三维数组转换为二维数组，然后转换为 Pandas DataFrame
result_flat = result.reshape(-1, result.shape[-1])
result_df = pd.DataFrame(result_flat)

# 保存到 Excel
result_df.to_excel("2023华数B/Q2单色.xlsx", index=False)
