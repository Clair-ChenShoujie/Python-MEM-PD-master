import numpy as np
import pandas as pd

# 读取标准样数据
df1 = pd.read_excel("2023华数B/附件1.xlsx")
df2 = pd.read_excel("2023华数B/Q2ks.xlsx")
sums = []

# 遍历X,Y,Z列
results = []
for j in range(728):#728
    result_row = []
    for i in range(1, 4):
        Sxyz = df1.iloc[2:19, i].values.astype('float64')  # SX/SY/SZ
        ks = df2.iloc[j, 0:16].values.astype('float64')  # k/s
        R = 1 + ks - np.sqrt(ks**2 + 2*ks) # R
        print(R)
        result = np.multiply(Sxyz, R) * 20 * 0.1 # 进行元素相乘
        # print("样品", j+1, "\n", format(i), result, "\n")
        result_row.append(np.sum(result))
    results.append(result_row)

# 保存为xlsx文件
df_results = pd.DataFrame(results, columns=['X', 'Y', 'Z'])
df_results.to_excel("2023华数B/标准样XYZ.xlsx", index=False)