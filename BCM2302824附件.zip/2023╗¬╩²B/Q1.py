import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
import os

# 读取数据
df = pd.read_excel("2023华数B/附件2.xlsx")
x0 = [0.05, 0.1, 0.5, 1, 2, 3, 4, 5]

# 定义行范围和对应的文件夹名
row_range = [(2, 9), (10, 17), (18, 25)]
folder_names = ["Q1红", "Q1黄", "Q1蓝"]

# 设置 R^2 的增长阈值
r2_growth_threshold = 0.001

# 遍历不同的行范围和文件夹名
for row_idx, folder_name in enumerate(folder_names):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    
    # 遍历不同的列
    for col in range(2, 18):
        print(400 + (col - 2) * 20)
        row_start, row_end = row_range[row_idx]
        y0 = df.iloc[row_start:row_end + 1, col].values.astype('float64')

        # 初始化最优的模型参数
        best_degree = 0
        highest_r2 = float('-inf')

        # 遍历不同的多项式阶数
        for degree in range(1, 8):  # 从1阶开始到7阶
            # 线性拟合
            p = np.polyfit(x0, y0, degree)
            # 计算 R^2 值
            y_pred = np.polyval(p, x0)
            r2 = r2_score(y0, y_pred)
            # 判断 R^2 的增长是否低于阈值
            if degree > 1 and (r2 - highest_r2) < r2_growth_threshold:
                break
            if r2 > highest_r2:
                best_degree = degree
                highest_r2 = r2

        # 使用最优的阶数重新拟合数据
        p = np.polyfit(x0, y0, best_degree)

        print(f"最优的拟合阶数为: {best_degree}，对应的R^2值为: {highest_r2}")

        # 创建多项式对象
        fitted_curve = np.poly1d(p)
        # 输出拟合曲线的函数公式
        formula = str(fitted_curve)
        print(f"拟合曲线的函数公式为: {formula}\n")

        # 计算拟合曲线上的点
        x_fit = np.linspace(min(x0), max(x0), 100)
        y_fit = np.polyval(p, x_fit)

        # 绘制拟合曲线和原始数据点
        plt.scatter(x0, y0, label='Original Data')
        plt.plot(x_fit, y_fit, 'r', label='Fitted Curve')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title(f'Polynomial Fitting for Column {col}')
        plt.legend()

        # 构造文件名
        file_name = f"{folder_name}/{(col-2)*20 + 400}.png"

        # 保存图片
        plt.savefig(file_name)

        # 关闭当前图形窗口，防止内存溢出
        plt.close()
